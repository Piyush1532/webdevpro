/*let xhr = new XMLHttpRequest();
xhr.addEventListener("readystatechange",function(){
    console.log("Event occord");
    console.log(xhr.readyState);
    if( (xhr.status >=200 && xhr.status<400)&& xhr.readyState === 4){
        document.getElementById('demo').innerHTML=xhr.responseText;
    }
    else if(xhr.status >=400){
        alert("Cannot get the data")
    }
});

xhr.open("GET","quote.txt",true);
xhr.send();*/

// function ajax(method,url,success,error){
//     let xhr = new XMLHttpRequest();
// xhr.addEventListener("readystatechange",function(){
//     console.log("Event occord");
//     console.log(xhr.readyState);
//     if( (xhr.status >=200 && xhr.status<400)&& xhr.readyState === 4){
//        success(xhr.responseText);
//     }
//     else if(xhr.status >=400){
//        error();
//     }
// });

// xhr.open("GET","quote.txt",true);
// xhr.send();
// }

// function success(responseText){
//     document.getElementById('demo').innerHTML=responseText;

// }
// function error(){
//     alert("Cnnot get data")
// }
// ajax("GET","quote.txt",success,error);

function Makecall(){
    function ajax(method,url,success,error){
        let xhr = new XMLHttpRequest();
    xhr.addEventListener("readystatechange",function(){
        console.log("Event occord");
        console.log(xhr.readyState);
        if( (xhr.status >=200 && xhr.status<400)&& xhr.readyState === 4){
           success(xhr.responseText);
        }
        else if(xhr.status >=400){
           error();
        }
    });
    
    xhr.open("GET","quote.txt",true);
    xhr.send();
    }
    
    function success(responseText){
        document.getElementById('demo').innerHTML=responseText;
    
    }
    function error(){
        alert("Cannot get data")
    }
    ajax("GET","quote.txt",success,error);
}