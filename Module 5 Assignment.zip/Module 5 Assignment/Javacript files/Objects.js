var emp = {
    Employeename:"Rohan",
    Employeeno : 2344,
    Employeeage : 25,
    Employeedepatment : " Finance Management",
}

document.getElementById("empo").innerHTML = emp["Employeename"] + " is working in" + emp["Employeedepatment"];
console.log(emp)