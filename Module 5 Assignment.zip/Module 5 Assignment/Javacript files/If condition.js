function evn() {
    var a = prompt('enter your name name');
    if (a) {
        alert("welcome"  +  a)
    } else {
        alert("Sorry you have naot enterd your name")
    }

}
