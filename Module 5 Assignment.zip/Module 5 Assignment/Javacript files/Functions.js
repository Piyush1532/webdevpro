function largenum(){
    var numb1 = Number(prompt('Please enter first number'));
    var numb2 = Number(prompt('Please enter second number'));
    var numb3 = Number(prompt('Please enter third number'));

    if( numb1 > numb2 && numb1 > numb3){
        alert(`${numb1} is largest`)
    }else if (numb2 > num1 && numb2> numb3){
        alert(`${numb2} is largest`)
    } else {
        alert(`${numb3} is largest`)
    }
}

