var arr = ["Java","Javasript","C","Python","Css"]
function Computer(){
    alert(arr)
}
alert(arr)